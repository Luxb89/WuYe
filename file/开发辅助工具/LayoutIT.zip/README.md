layoutit
========

基于bootstrap实现可视化布局的layoutit.com离线中文版  
新增功能:  
html5自动保存, 开启元素立即编辑模式, 增加撤销,重做跟踪操作功能, 加入ckeditor弹出编辑器.  
原版程序地址: http://www.layoutit.com/build  

